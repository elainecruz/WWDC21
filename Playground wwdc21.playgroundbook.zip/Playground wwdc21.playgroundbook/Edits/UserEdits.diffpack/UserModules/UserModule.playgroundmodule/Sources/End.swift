

import UIKit
import PlaygroundSupport


public class End1ViewController: UIViewController{
    var font = UIFont()
    var cardWidth = 200
    var cardHeight = 200
    public override func viewDidLoad() {
        super.viewDidLoad()
        CTFontManagerRegisterFontsForURL(cfURL as CFURL, CTFontManagerScope.process, nil)
        font = UIFont(name: "Rowdies-Light", size: 30)!
        
        
        self.view.frame = CGRect(x: 0, y: 0, width: 400, height: 600)
        
        var bg = UIImageView(image: UIImage(named: "bgClaro1" ))
        bg.frame = CGRect(x: 50, y:50 , width: 668, height: 824)
        self.view.addSubview(bg)
        var texto = UILabel()
        texto.text = "So these are some of the amazing women around me"
        texto.frame = CGRect(x: 120, y: 0, width: 520, height: 300)
        texto.textColor = .black
        texto.font = font
        texto.textAlignment = .center
        texto.numberOfLines = 0
        self.view.addSubview(texto)
        
        var morgs = UIImageView(image: UIImage(named: "MorgsAvatar" ))
        morgs.frame = CGRect(x: 100, y:200 , width: cardWidth, height: cardHeight)  
        self.view.addSubview(morgs)
        
        
        var iris = UIImageView(image: UIImage(named: "IrisAvatar" ))
        iris.frame = CGRect(x: 290, y:450 , width: cardWidth, height: cardHeight+10)
        self.view.addSubview(iris)
        
        
        var jessica = UIImageView(image: UIImage(named: "JessicaAvatar" ))
        jessica.frame = CGRect(x: 310, y:230 , width: cardWidth, height: cardHeight)
        self.view.addSubview(jessica)
        
        
        var xanda = UIImageView(image: UIImage(named: "XandaAvatar" ))
        xanda.frame = CGRect(x: 450, y:530 , width: cardWidth, height: cardHeight)
        self.view.addSubview(xanda)
        
        
        var duda = UIImageView(image: UIImage(named: "DudaAvatar" ))
        duda.frame = CGRect(x: 60, y: 400, width: cardWidth, height: cardHeight)
        self.view.addSubview(duda)
        
        var mayara = UIImageView(image: UIImage(named: "MayaAvatar" ))
        mayara.frame = CGRect(x: 490, y: 270, width: cardWidth, height: cardHeight)
        self.view.addSubview(mayara)
        
        var dara = UIImageView(image: UIImage(named: "DaraAvatar" ))
        dara.frame = CGRect(x: 170, y: 650, width: cardWidth+10, height: cardHeight+10)
        self.view.addSubview(dara)
        
        
        
        var nextBtm = UIButton()
        nextBtm.frame = CGRect(x: 610, y: 750, width: 30, height: 40)
        nextBtm.setImage(UIImage(named: "nextDark"), for: .normal)
        nextBtm.addTarget(self, action: #selector(tappedNext), for: .touchUpInside)
        self.view.addSubview(nextBtm)
        
        
    }
    
    @objc func tappedNext(){
        navigation.pushViewController(End2ViewController(), animated: false)
        
    }
    
}

public class End2ViewController: UIViewController{
    var font = UIFont()
    public override func viewDidLoad() {
        super.viewDidLoad()
        CTFontManagerRegisterFontsForURL(cfURL as CFURL, CTFontManagerScope.process, nil)
        font = UIFont(name: "Rowdies-Light", size: 30)!
        
        self.view.frame = CGRect(x: 0, y: 0, width: 400, height: 600)
        
        var bg = UIImageView(image: UIImage(named: "bgClaro2" ))
        bg.frame = CGRect(x: 50, y:50 , width: 668, height: 824)
        self.view.addSubview(bg)
        
        var texto = UILabel()
        texto.text = "What about around you?"
        texto.frame = CGRect(x: 120, y: 30, width: 520, height: 300)
        texto.textColor = .black
        texto.font = font
        texto.textAlignment = .center
        texto.numberOfLines = 0
        self.view.addSubview(texto)
        
        var card = UIImageView(image: UIImage(named: "Group 6" ))
        card.frame = CGRect(x: 220, y:270 , width:340, height: 500)
        
        self.view.addSubview(card)
        
    }
    
}


