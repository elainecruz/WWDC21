
import UIKit
import PlaygroundSupport


let cfURL = Bundle.main.url(forResource: "Rowdies-Light", withExtension: "ttf")!

public class IntroductionViewController: UIViewController{
    var font = UIFont()
    var buttonCount = 0
    var elaine1 = UIImageView()
    var nextBtm = UIButton()
    var letsBtm = UIButton()
    
    
    var helloText = UILabel()
    var text = UILabel()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        CTFontManagerRegisterFontsForURL(cfURL as CFURL, CTFontManagerScope.process, nil)
        font = UIFont(name: "Rowdies-Light", size: 25)!
        
        self.view.frame = CGRect(x: 0, y: 0, width: 200, height: 300)
        var bg = UIImageView(image: UIImage(named: "cardBg2" ))
        bg.frame = CGRect(x: 50, y:50 , width: 668, height: 824)
        self.view.addSubview(bg)
        
        
        elaine1 = UIImageView(image: UIImage(named: "Elaine1" ))
        elaine1.frame = CGRect(x: 275, y:190 , width: 210, height: 210)  
        self.view.addSubview(elaine1)
        
        
        
        helloText.text = "Hello!"
        helloText.frame = CGRect(x: 230, y: 320, width: 320, height: 300)
        helloText.textColor = .white
        helloText.font = font
        helloText.font = helloText.font.withSize(38)
        helloText.textAlignment = .center
        helloText.numberOfLines = 0
        self.view.addSubview(helloText)
        
        text.text = "My name is Elaine Cruz and I am a undergraduate student of Computer Science in Brazil"
        text.frame = CGRect(x: 195, y: 360, width: 380, height: 400)
        text.textColor = .white
        text.font = font
        text.font = text.font.withSize(25)
        
        text.textAlignment = .center
        text.numberOfLines = 0
        self.view.addSubview(text)
        
        
        nextBtm.frame = CGRect(x: 540, y: 690, width: 26, height: 30)
        nextBtm.setImage(UIImage(named: "nextArrow"), for: .normal)
        nextBtm.addTarget(self, action: #selector(tappedNext), for: .touchUpInside)
        self.view.addSubview(nextBtm)
        
        letsBtm.frame = CGRect(x: 220, y: 640, width: 340, height: 50)
        letsBtm.setImage(UIImage(named: "letsgo"), for: .normal)
        letsBtm.addTarget(self, action: #selector(tappedLetsGo), for: .touchUpInside)
        letsBtm.isHidden = true
        self.view.addSubview(letsBtm)
        
        
    }
    
    @objc func tappedLetsGo(){
        navigation.pushViewController(ARViewController(), animated: false)
    }
    
    @objc func tappedNext(){
        print("entrouu")
        buttonCount += 1
        
        if buttonCount==1{
            elaine1.isHidden = true
            helloText.isHidden = true
            text.text = "I have often struggled and felt alone due to the fact that I am a woman in such a male dominated area"
            text.font =  text.font.withSize(26)
            text.frame = CGRect(x: 190, y: 270, width: 380 , height: 400)
            
        }else if(buttonCount==2){
            text.text = "But many amazing women have crossed my path and made me feel like I belonged and that I wasn’t alone"
            text.font =  text.font.withSize(25)
            text.frame = CGRect(x: 190, y: 300, width: 380 , height: 400)
            
            elaine1.isHidden = false
            elaine1.image = UIImage(named: "Elaine2" )
            elaine1.frame = CGRect(x: 280, y:200 , width: 210, height: 210)  
            
        }else if(buttonCount==3){
            elaine1.isHidden = true
            
            text.text = "Today I want  you to meet a very special portion of these women: \n \n The IT girls of the Apple Developer Academy UFPE ecosystem"
            text.font =  text.font.withSize(25)
            text.frame = CGRect(x: 190, y: 270, width: 380 , height: 400)
            
        }else if(buttonCount==4){
            text.text = "And all you will have to do is look around you!"
            text.font =  text.font.withSize(26)
            text.frame = CGRect(x: 190, y: 270, width: 380 , height: 400)
            
            
        }else{
            text.text = "Ready for an augmented reality memory game?"
            text.font =  text.font.withSize(26)
            text.frame = CGRect(x: 190, y: 100, width: 380 , height: 400)
            elaine1.isHidden = false
            nextBtm.isHidden = true
            letsBtm.isHidden = false
            elaine1.image = UIImage(named: "Elaine3" )
            elaine1.frame = CGRect(x: 320, y:365 , width: 160, height: 180)  
        }
    }
    
}
