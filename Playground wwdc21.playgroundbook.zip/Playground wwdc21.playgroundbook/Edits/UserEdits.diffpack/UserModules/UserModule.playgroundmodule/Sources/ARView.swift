import UIKit
import PlaygroundSupport
import RealityKit


var cards: [Entity] = []
var girlsNames = ["Morgana", "Morgana", "Iris", "Iris", "Jessica", "Jessica", "Duda", "Duda", "Xanda", "Xanda", "Dara", "Dara", "Mayara", "Mayara"]
var girlsSimpleCards = ["Morgscard.png", "Morgscard.png", "IrisCard.png", "IrisCard.png", "JessicaCard.png", "JessicaCard.png", "DudaCard", "DudaCard", "XandaCard", "XandaCard", "DaraCard", "DaraCard", "MayaraCard", "MayaraCard"]
var totalCards = 7
var cardUpCounter = 0
var cardFoundCounter = 0
var entitiesUp: [Entity] = []
var aux = false

//Create ARView
let frame = CGRect(x: 0, y: 0, width: 668, height: 824)
let arView = ARView(frame: frame, cameraMode: .ar, automaticallyConfigureSession: true)


class ARViewController: UIViewController {
    
    var popUp = UIImageView()
    var popUpButton = UIButton()
    var textFound = UILabel()
    var popUpCard = UIImageView()
    
    var finishedPopUp = UIImageView()
    var finishedpopUpButton = UIButton()
    var font = UIFont()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        CTFontManagerRegisterFontsForURL(cfURL as CFURL, CTFontManagerScope.process, nil)
        font = UIFont(name: "Rowdies-Light", size: 25)!
        
        loadArView()
        ActivateTouch()
        
        
        
        popUp = UIImageView(image: UIImage(named: "popUpRectClaro-2" ))
        popUp.frame = CGRect(x: 50, y:50 , width: 568, height: 724)
        
        textFound.frame = CGRect(x: 35, y: 0, width: 500, height: 200)
        textFound.text = "This is \n Morgana Galamba!"
        textFound.textColor = .black
        textFound.font = font
        textFound.font = textFound.font.withSize(35)
        textFound.textAlignment = .center
        textFound.numberOfLines = 0
        popUp.addSubview(textFound)
        popUpCard = UIImageView(image: UIImage(named: "Morgana"))
        popUpCard.frame = CGRect(x: 120, y:190 , width: 330, height: 490)
        popUp.addSubview(popUpCard)
        
        popUpButton.setImage(UIImage(named: "checkDark"), for: .normal)
        popUpButton.frame = CGRect(x: 570, y: 720, width: 70, height: 70)
        popUpButton.addTarget(nil, action: #selector(closePopUp), for: .touchUpInside)
        
        popUp.isHidden = true
        popUpButton.isHidden = true
        self.view.frame = arView.frame
        
        
        finishedPopUp = UIImageView(image: UIImage(named: "popUpRectClaro-2" ))
        finishedPopUp.frame = CGRect(x: 45, y:30 , width: 568, height: 724)
        
        var finishedPopUpText = UILabel()
        finishedPopUpText.frame = CGRect(x: 10, y:120 , width: 550, height: 500)
        finishedPopUpText.text = "Congratulations, \n you found all the pairs!"
        finishedPopUpText.textColor = .black
        finishedPopUpText.font = font
        finishedPopUpText.font = textFound.font.withSize(35)
        finishedPopUpText.textAlignment = .center
        finishedPopUpText.numberOfLines = 0
        finishedPopUp.addSubview(finishedPopUpText)
        
        var elaine = UIImageView(image: UIImage(named: "Elaine4" ))
        elaine.frame = CGRect(x: 180, y: 70 , width: 220, height: 220)
        finishedPopUp.addSubview(elaine)
        
        finishedpopUpButton.setImage(UIImage(named: "checkDark"), for: .normal)
        finishedpopUpButton.frame = CGRect(x: 290, y: 530, width: 80, height: 80)
        finishedpopUpButton.addTarget(nil, action: #selector(gameDone), for: .touchUpInside)
        finishedPopUp.isHidden = true
        finishedpopUpButton.isHidden = true
        
        self.view.addSubview(arView)
        self.view.addSubview(popUp)
        self.view.addSubview(popUpButton)
        self.view.addSubview(finishedPopUp)
        self.view.addSubview(finishedpopUpButton)
        
        
        
        
    }
    
    func loadArView(){
        for i in 0...girlsNames.count-1 {
            let anchorEntity = AnchorEntity(plane: .horizontal)
            arView.scene.addAnchor(anchorEntity)
            let mesh = MeshResource.generateBox(width: 0.3, height: 0.002, depth: 0.3)
            
            var simpleMaterial = SimpleMaterial()
            simpleMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "Group 6.png"))
            
            var girlMaterial = SimpleMaterial()
            if(girlsNames[i] == "Morgana"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "MorgsCard.png"))
            }else if(girlsNames[i] == "Iris"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "IrisCard.png"))
            }else if (girlsNames[i] == "Jessica"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "JessicaCard.png"))
            }else if(girlsNames[i] == "Duda"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "DudaCard.png"))
            }else if(girlsNames[i] == "Xanda"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "XandaCard.png"))
            }else if(girlsNames[i] == "Dara"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "DaraCard.png"))
            }else if(girlsNames[i] == "Mayara"){
                girlMaterial.baseColor = try! MaterialColorParameter.texture(TextureResource.load(named: "MayaraCard.png"))
            }
                
            let modelEntity2 = ModelEntity(mesh: mesh, materials: [girlMaterial])
            modelEntity2.generateCollisionShapes(recursive: true)
            
            let modelEntity = ModelEntity(mesh: mesh, materials: [simpleMaterial,girlMaterial])
            modelEntity.generateCollisionShapes(recursive: true)
            modelEntity.setPosition([Float.random(in: 0..<2), Float.random(in: -1..<0.5), Float.random(in: 0..<3)], relativeTo: anchorEntity)
            
            modelEntity2.name = girlsNames[i]
            modelEntity.name = girlsNames[i]
            modelEntity.addChild(modelEntity2)
            modelEntity2.isEnabled = false
            
            anchorEntity.addChild(modelEntity)
            //arView.installGestures(for: modelEntity)
        }
    }
    @objc func closePopUp(){
        print("oi")
        popUp.isHidden = true
        popUpButton.isHidden = true
        
        if(cardFoundCounter==totalCards){
            finishedPopUp.isHidden = false
            finishedpopUpButton.isHidden = false
            
        }
        
    }
    
    @objc func gameDone(){
        navigation.pushViewController(End1ViewController(), animated: false)
    }
    
    func ActivateTouch(){
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector (TappedCard(recognizer: )))
        
        arView.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func openPopUp(girl: String){
        print(girl)
        if (girl == "Morgana"){
            textFound.text = "This is \n Morgana Galamba"
            popUpCard.image = UIImage(named: "Morgana.png")
            
        }else if (girl == "Iris"){
            textFound.text = "This is \n Íris Soares!"
            popUpCard.image = UIImage(named: "Iris.png")
            
        }else if(girl == "Jessica"){
            textFound.text = "This is \n Jéssica Almeida!"
            popUpCard.image =  UIImage(named: "Jéssica.png")
        }else if(girl == "Duda"){
            textFound.text = "This is \n Eduarda Senna!"
            popUpCard.image =  UIImage(named: "Duda.png")
        }else if(girl == "Xanda"){
            textFound.text = "This is \n Alexandra Zarzar!"
            popUpCard.image =  UIImage(named: "Xanda.png")
        }else if(girl == "Dara"){
            textFound.text = "This is \n Dara Vasconcelos!"
            popUpCard.image =  UIImage(named: "Dara.png")
        }else if(girl == "Mayara"){
            textFound.text = "This is \n Mayara Mendonça!"
            popUpCard.image =  UIImage(named: "Mayara.png")
        }
        popUp.isHidden = false
        popUpButton.isHidden = false
    }
    
    @objc func TappedCard(recognizer: UITapGestureRecognizer){
        let location = recognizer.location(in: arView)
        
        if let entity = arView.entity(at: location){
            print(entity.name)
            
            if aux && entity.parent?.transform.rotation.angle == .pi {
                aux = false
                entity.isEnabled = false
                var flipDownTransform = entity.parent?.transform
                flipDownTransform?.rotation = simd_quatf(angle: 0, axis: [1,0 , 0])
                entity.parent?.move(to: flipDownTransform!, relativeTo: entity.parent?.anchor, duration: 0.25, timingFunction: .easeInOut)
                
                cardUpCounter-=1
                entitiesUp = []
            }else{
                aux = true
                entity.children.first?.isEnabled = true
                var flipUpTransform = entity.transform
                flipUpTransform.rotation = simd_quatf(angle: .pi, axis: [1,0,0])
                entity.move(to: flipUpTransform, relativeTo: entity.parent, duration: 0.25, timingFunction: .easeInOut)
                
                cardUpCounter = cardUpCounter + 1
                entitiesUp.append((entity.children.first)!)
                
                if(cardUpCounter==2){
                    cardUpCounter = 0
                    
                    if(entitiesUp[0].name == entitiesUp[1].name){
                        let  girlName = entitiesUp[0].name
                        //Você achou um par
                        cardFoundCounter += 1
                        
                        //Removendo ancoras das cartas encontradas da cena
                        let seconds = 0.6
                        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                            
                            arView.scene.removeAnchor((entitiesUp[0].parent?.anchor)!)
                            arView.scene.removeAnchor((entitiesUp[1].parent?.anchor)!)
                            entitiesUp = []
                        }
                        
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [self] in
                            openPopUp(girl: girlName)
                        }
                        
                        
                    }else{
                        aux = false
                        
                        //Virando as cartas de volta 
                        let seconds = 0.4
                        DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
                            
                            entitiesUp[0].isEnabled = false
                            var flipDownTransform1 = entitiesUp[0].parent?.transform
                            flipDownTransform1?.rotation = simd_quatf(angle: 0, axis: [1,0 , 0])
                            entitiesUp[0].parent?.move(to: flipDownTransform1!, relativeTo: entitiesUp[0].parent?.anchor, duration: 0.2, timingFunction: .easeInOut)
                            
                            entitiesUp[1].isEnabled = false
                            var flipDownTransform2 = entitiesUp[1].parent?.transform
                            flipDownTransform2?.rotation = simd_quatf(angle: 0, axis: [1,0 , 0])
                            entitiesUp[1].parent?.move(to: flipDownTransform2!, relativeTo: entitiesUp[1].parent?.anchor, duration: 0.2, timingFunction: .easeInOut)                        
                            entitiesUp = []
                        }
                        
                        
                        
                    }
                }
                
                
                
            }
            
            
        }
    }
    
}




